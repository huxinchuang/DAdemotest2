#!/usr/bin/env python
#-*- coding:utf-8 -*-

from setuptools import setup, find_packages

setup(
	name = "DeAlSys",
	version = "0.3",
	#url = 'https://github.com/snowroll/python-sdk.git',
	#long_description = open('README.md',encoding='utf-8').read(),
	#packages = find_packages(),
	#packages = find_packages('DeAlSys'),  # 包含所有src中的包
    #package_dir = {'':'DeAlSys'},   # 告诉distutils包都在src下
	packages = ['DeAlSys'],
	install_requires=[    # 依赖列表
		#'Flask>=0.10',
		#'Flask-SQLAlchemy>=1.5,<=2.1',
		'xlrd==1.2.0',
		'numpy==1.19.2',
		'pandas==1.1.3',
		'scikit-learn==0.23.2',
		'dataclasses>=0.8',
    ]
)

'''
name 包的名字
version 依赖关系很重要
packages 需要包含的子包列表，用find_packages()查找
url：包的链接，通常为 Github 上的链接，或者是 readthedocs 链接
setup_requires：指定依赖项
test_suite：测试时运行的工具
'''