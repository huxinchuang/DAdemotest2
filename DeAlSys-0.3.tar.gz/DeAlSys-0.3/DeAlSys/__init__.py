from .onehot import *
from .ConsecutiveData import *
from .main_test import *
from .Normalization import *

def test():
    print('helloworld!!!')