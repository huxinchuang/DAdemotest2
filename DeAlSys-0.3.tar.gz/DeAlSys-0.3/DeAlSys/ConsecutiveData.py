"""
文件说明：针对连续性数据的离散化脱敏算法实现
原理：根据读入的数据集中的某一个数据项，根据等宽法、等频法等，将值域划分为设定的若干个块，将每一个数据项映射为对应的值域
"""
import pandas as pd


# 使用分箱操作对“年龄”进行脱敏
def boxOperation_age(ages):
    """
    使用等宽法对年龄进行脱敏
    :param ages:输入待脱敏的的年龄列表
    :return:每一个年龄所属的年龄段列表
    """
    bins = [10, 18, 25, 35, 60, 100]    # 指定箱子的分界点
    # 可以将想要指定给不同箱子的标签传递给labels参数
    group_names = ['teenager', 'Youth', 'Middle-Young', 'Middle-Aged', 'Senior']
    cat1 = pd.cut(ages, bins, labels=group_names)
    return list(cat1)


if __name__ == '__main__':
    ages = [20, 22, 25, 27, 21, 61]     # 待脱敏年龄列表
    Cate_Age = boxOperation_age(ages)
    print(Cate_Age)