from sklearn.preprocessing import OneHotEncoder


# 1. 0_1展示的onehot表示函数

# 对“性别”进行脱敏
def onehot_Gender(gen):
    Des_gen = [1] * len(gen)        # 默认为男士，置为'1'
    for i in range(len(gen)):
        if gen[i] == '女':  # 女性则表示为0
            Des_gen[i] = 0

    return Des_gen


# 对“是否有房”进行脱敏
def onehot_House(hou):
    Des_hou = [1] * len(hou)  # 默认为'有房'，置为'1'
    for i in range(len(hou)):
        if hou[i] == '无':  # 无房则表示为‘0’
            Des_hou[i] = 0
    return Des_hou


# 2. 用onehot编码表示的脱敏数据项

# 对“手机操作系统”进行脱敏
def onehot_OS(os):
    if os == 'Symbian':
        a = 0
    elif os == 'Palm':
        a = 1
    elif os == 'BlackBerry':
        a = 2
    elif os == 'ios':
        a = 3
    elif os == 'Windows mobile':
        a = 4
    elif os == 'Linux':
        a = 5
    elif os == 'Android':
        a = 6
    elif os == 'HarmonyOS':
        a = 7
    else:
        a = 8
        
    enc = OneHotEncoder()
    enc.fit([[0], [1], [2], [3], [4], [5], [6], [7], [8]])
            
    ans = enc.transform([[a]]).toarray()
    return ans


if __name__=='__main__':
    print('可供选择的手机系统：Symbian、Palm、BlackBerry、ios、Windows mobile、Linux、Android、HarmonyOS')
    OS = input('选择手机系统：')
    ans = onehot_OS(OS)
    print(ans)