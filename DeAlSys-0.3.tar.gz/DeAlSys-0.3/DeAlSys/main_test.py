from .ConsecutiveData import boxOperation_age
from .onehot import onehot_Gender, onehot_House
from .Normalization import MaxMin_Mormal
import pandas as pd
import numpy as np

def DeAlTest(input_src,output_src):
    #data = pd.read_excel('./data/random_data.xlsx')
    data = pd.read_excel(input_src)
    # 对'性别'数据脱敏
    genders = np.array(data.iloc[:, [1]].stack()).tolist()   # 读取第一列数据：性别，然后将pandas读取的数据转化为list
    Des_genders = onehot_Gender(genders)

    # 对'年龄'数据脱敏
    ages = np.array(data.iloc[:, [2]].stack()).tolist()   # 读取第二列数据：年龄，然后将pandas读取的数据转化为list
    Des_ages = boxOperation_age(ages)

    # 对'薪资'数据脱敏
    salarys = np.array(data.iloc[:, [3]].stack()).tolist()   # 读取第三列数据：年薪，然后将pandas读取的数据转化为list
    Des_salarys = MaxMin_Mormal(salarys)

    # 对'是否有房'数据脱敏
    House = np.array(data.iloc[:, [4]].stack()).tolist()   # 读取第四列数据：房，然后将pandas读取的数据转化为list
    Des_hou = onehot_House(House)

    # 保存脱敏后的数据
    frame = pd.DataFrame({'性别': Des_genders, '年龄': Des_ages, '薪资': Des_salarys, '有房': Des_hou})
    #frame.to_csv('./data/Des_data.csv', index=False, sep=',')
    frame.to_csv(output_src+'/Des_data.csv', index=False, sep=',')
    print('Main test is over')
    print('please check output!')