from .des_consecutive_data import consecutive_discretized_desensitization
from .des_onehot import desensitization_onehot_01, desensitization_onehot_mul_val
from .des_normalization import desensitization_normalized
from .des_hash import desensitization_hash
from .des_time import desensitization_time
import pandas as pd
import numpy as np


if __name__ == '__main__':
    data = pd.read_excel('./data/test_data3.xlsx')

    # 对'性别'数据脱敏 （onehot）
    genders = np.array(data.iloc[:, [1]].stack()).tolist()   # 读取第二列数据：性别，然后将pandas读取的数据转化为list
    Des_genders = desensitization_onehot_01(genders, 0, ['男', '女'])
    # Des_genders_1 = onehot_0_1(genders, 2)
    # print(Des_genders_0)
    # print(Des_genders_1)
    # print()
    #
    # 对'是否有房'数据脱敏（onehot）
    House = np.array(data.iloc[:, [6]].stack()).tolist()   # 读取第七列数据：房，然后将pandas读取的数据转化为list
    Des_hou = desensitization_onehot_01(House, 0, ['有', '无'])
    # Des_hou_1 = onehot_0_1(House, 1)
    # print(Des_hou_0)
    # print(Des_hou_1)

    # Des_hou = onehot_House(House)
    # print(Des_hou)

    # 对”职业“数据进行脱敏（one-hot脱敏）
    PROFESSIONs = np.array(data.iloc[:, [3]].stack()).tolist()  # 读取第四列数据：职业，然后将pandas读取的数据转化为list
    Des_pro = desensitization_onehot_mul_val(PROFESSIONs, 0, ['工人', '公务员', '个体商人', '教师', '程序员', '学生'])
    # Des_pro_1 = onehot_mul_val(PROFESSIONs, 1)
    # print(Des_pro_0)
    # print(Des_pro_1)

    # 对'操作系统'数据进行脱敏处理（one-hot脱敏）
    PHONE_OS = np.array(data.iloc[:, [7]].stack()).tolist()  # 读取第八列数据：职业，然后将pandas读取的数据转化为list
    Des_phone = desensitization_onehot_mul_val(PHONE_OS, 2)
    # Des_phone_1 = onehot_mul_val(PHONE_OS, ['Symbian', 'Palm', 'BlackBerry', 'ios', 'Windows mobile', 'Linux',
    #                                         'Android', 'HarmonyOS'])
    # print(Des_phone_0)
    # print(Des_phone_1)

    # 对'用户等级'数据进行脱敏处理(one-hot脱敏)
    WO_USER_VALUE = np.array(data.iloc[:, [8]].stack()).tolist()  # 读取第九列数据：用户等级，然后将pandas读取的数据转化为list
    Des_WO_USER = desensitization_onehot_mul_val(WO_USER_VALUE, 2)
    # Des_WO_USER_1 = onehot_mul_val(WO_USER_VALUE, ['小富', '大富', '百富', '巨富'])
    # print(Des_WO_USER_0)
    # print(Des_WO_USER_1)


    # 对”用户编号“数据脱敏（hash脱敏）
    user_no = np.array(data.iloc[:, [0]].stack()).tolist()  # 读取第一列数据：用户编号，然后将pandas读取的数据转化为list
    Des_user_no = desensitization_hash(user_no)
    # print(Des_user_no)

    # 对”手机号码“数据进行脱敏（hash脱敏）
    PHONE_NOs = np.array(data.iloc[:, [5]].stack()).tolist()  # 读取第六列数据：手机号码，然后将pandas读取的数据转化为list
    Des_pho = desensitization_hash(PHONE_NOs)
    # print(Des_pho)


    # 对'薪资'数据脱敏 （max-min归一化脱敏）
    salarys = np.array(data.iloc[:, [4]].stack()).tolist()   # 读取第五列数据：年薪，然后将pandas读取的数据转化为list
    Des_salarys = desensitization_normalized(salarys)
    # print(Des_salarys)

    # 对'最近一个月登录次数'数据进行脱敏处理（max-min归一化脱敏）
    LOGIN_NUM1 = np.array(data.iloc[:, [9]].stack()).tolist()  # 读取第十列数据：最近一个月登录次数，然后将pandas读取的数据转化为list
    Des_login_num = desensitization_normalized(LOGIN_NUM1)
    # print(Des_login_num)

    # 对'最近六个月交易次数'数据进行脱敏处理（max-min归一化脱敏）
    TRADE_ALL_NUM6 = np.array(data.iloc[:, [10]].stack()).tolist()  # 读取第十一列数据：最近6个月的交易次数，然后将pandas读取的数据转化为list
    Des_Trade_num6 = desensitization_normalized(TRADE_ALL_NUM6)
    # print(Des_Trade_num6)

    # 对'最近6个月的交易金额'数据进行脱敏处理（max-min归一化脱敏）
    TRADE_ALL_AMT6 = np.array(data.iloc[:, [11]].stack()).tolist()  # 读取第十二列数据：最近6个月的交易金额，然后将pandas读取的数据转化为list
    Des_Trade_AMT6 = desensitization_normalized(TRADE_ALL_AMT6)
    # print(Des_Trade_AMT6)

    # 需根据后续同一类型的字段的脱敏实现情况进行改进

    # 对'年龄'数据脱敏 (连续值脱敏-离散化-分箱脱敏)
    ages = np.array(data.iloc[:, [2]].stack()).tolist()   # 读取第三列数据：年龄，然后将pandas读取的数据转化为list
    Des_ages = consecutive_discretized_desensitization(ages, discretized_algorithm=0, num_interval=5)
    # print(Des_ages)

    # 对'最近交易时间'数据进行脱敏处理（先求时间间隔，再对时间间隔做Max-Min归一化脱敏）
    LATELY_ALL_TRADE_TIME = list(data.iloc[:, [12]].stack())    # 读取第十三列数据：最近交易时间，然后将pandas读取的数据转化为list
    # LATELY_ALL_TRADE_TIME = [str(LATELY_ALL_TRADE_TIME[i])[:10] for i in range(len(LATELY_ALL_TRADE_TIME))]

    Des_Lately_Trade_Time = desensitization_time(LATELY_ALL_TRADE_TIME, time_granularity='year')
    print(Des_Lately_Trade_Time)

    # 保存脱敏后的数据
    frame = pd.DataFrame({'用户编号': Des_user_no,
                          '性别': Des_genders,
                          '年龄': Des_ages,
                          '职业': Des_pro,
                          '薪资': Des_salarys,
                          '手机号码': Des_pho,
                          '有房': Des_hou,
                          '操作系统': Des_phone,
                          '用户等级': Des_WO_USER,
                          '最近一个月登录次数': Des_login_num,
                          '最近六个月交易次数': Des_Trade_num6,
                          '最近六个月的交易金额': Des_Trade_AMT6,
                          # '最近交易时间': Des_Lately_Trade_Time
                          })
    frame.to_csv('./data/Des_data2.csv', index=False, sep=',')
