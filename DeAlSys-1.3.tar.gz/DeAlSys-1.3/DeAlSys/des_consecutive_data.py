"""
文件说明：针对连续性数据的离散化脱敏算法实现
原理：针对读入的数据集中的某一个数据项，根据等宽法、等频法等，将值域划分为设定的若干个块，将每一个数据项映射为对应的值域
"""
import pandas as pd


def equal_width_method(unprocessed_data, width_interval=0):
    """
    等宽法实现
    :param unprocessed_data:
    :param width_interval:
    :return:
    """
    cat1 = pd.cut(unprocessed_data, width_interval, labels=range(width_interval))
    return list(cat1)


def equal_frequency_method(unprocessed_data, num_interval=0):
    """
    等频法实现
    :param unprocessed_data:
    :param num_interval:
    :return:
    """
    cat1 = pd.qcut(unprocessed_data, num_interval, labels=range(num_interval))
    return list(cat1)


def spef_bins_method(unprocessed_data, bins=None):
    """
    按指定的间隔分箱
    :param unprocessed_data:
    :param bins:
    :return:
    """
    cat1 = pd.cut(unprocessed_data, bins=bins, labels=range(len(bins) - 1))
    return cat1


# 连续值离散化脱敏
def consecutive_discretized_desensitization(unprocessed_data, discretized_algorithm='equal_width', num_interval=0,
                                            bins=None):
    """
    连续值离散化脱敏算法，可选的离散化方法有：等宽法、等频法等
    :param unprocessed_data:
    :param discretized_algorithm: 取值及对应的离散化方法： ‘equal_width’：等宽法； ‘equal_freq’：等频法；
                                                        ‘Spef_bins’: 按指定的分箱断点bins进行分类
    :return:
    """
    # 判定输入合法
    assert discretized_algorithm in ['equal_width', 'equal_freq', 'Spef_bins']

    if discretized_algorithm == 'equal_width':
        return equal_width_method(unprocessed_data, num_interval)
    elif discretized_algorithm == 'equal_freq':
        return equal_frequency_method(unprocessed_data, num_interval)
    elif discretized_algorithm == 'Spef_bins':
        return spef_bins_method(unprocessed_data, bins)


if __name__ == '__main__':
    ages = [20, 22, 35, 47, 21, 61]     # 待脱敏年龄列表
    Cate_Age = consecutive_discretized_desensitization(ages, discretized_algorithm='Spef_bins', num_interval=5,
                                                    bins=[18, 25, 35, 55, 70])
    print(Cate_Age)