import numpy as np


def normalized_max_min(unprocessed_data):
    """
    (0,1)标准化算法实现
    :param unprocessed_data:
    :return:
    """
    return (unprocessed_data - np.min(unprocessed_data, axis=0)) / \
           (np.max(unprocessed_data, axis=0) - np.min(unprocessed_data, axis=0))


def normalized_Z_score(unprocessed_data):
    """
    Z_score标准化算法实现
    :param unprocessed_data:
    :return:
    """
    data_mean = np.mean(unprocessed_data)
    data_std = np.std(unprocessed_data)
    return (unprocessed_data - data_mean) / data_std


def desensitization_normalized(unprocessed_data, normalized_algorithm='max_min'):
    """
    根据用户选择的归一化算法(默认采用(0,1)标准化)，对输入数据进行归一化脱敏处理
    :param unprocessed_data: 待脱敏数据
    :param normalized_algorithm: 指定的脱敏算法编号：'max_min'：(0,1)标准化； 'z_score'：Z-score标准化；
    :return:
    """
    # 判定输入合法
    assert normalized_algorithm in ['max_min', 'z_score']
    if normalized_algorithm == 'max_min':
        return normalized_max_min(unprocessed_data)
    elif normalized_algorithm == 'z_score':
        return normalized_Z_score(unprocessed_data)


if __name__ == '__main__':
    salarys = [978619, 32654, 512924, 157720, 764750, 699803, 757468, 525079, 28842, 176911]
    Normal_Sal = desensitization_normalized(salarys, 'z_score')
    print(Normal_Sal)


