"""
文件说明：哈希脱敏算法实现
"""
import hashlib


def hash256(unprocessed_data):
    res = []
    for i in range(len(unprocessed_data)):
        binaries = str(unprocessed_data[i]).encode('utf8')
        res.append(hashlib.sha256(binaries).hexdigest())
    return res


def hash224(unprocessed_data):
    res = []
    for i in range(len(unprocessed_data)):
        binaries = str(unprocessed_data[i]).encode('utf8')
        res.append(hashlib.sha224(binaries).hexdigest())
    return res


def md5(unprocessed_data):
    res = []
    for i in range(len(unprocessed_data)):
        binaries = str(unprocessed_data[i]).encode('utf8')
        res.append(hashlib.md5(binaries).hexdigest())
    return res


def desensitization_hash(unprocessed_data, hash_algorithm='hash224'):
    """
    根据用户选择的hash脱敏算法(默认采用hash224)，对输入数据进行哈希脱敏处理
    :param unprocessed_data: 带脱敏数据列表
    :param hash_algorithm: 可选的哈希脱敏算法：'hash224'、'hash256'、'md5'
    :return: 脱敏后的数据列表
    """
    # 判定输入合法
    assert hash_algorithm in ['hash224', 'hash256', 'md5']

    if hash_algorithm == 'hash224':
        return hash224(unprocessed_data)
    elif hash_algorithm == 'hash256':
        return hash256(unprocessed_data)
    elif hash_algorithm == 'md5':
        return md5(unprocessed_data)


if __name__ == '__main__':
    USER_NO = [719112608, 634908102, 935065281, 862633939, 910625206, 208955311, 427389667, 571340345, 308527721, 589805272]
    PHONE_NO = [14392372461, 15358753163, 15368219577, 18679118120, 18514343397, 15373199026, 14923115681, 14506583419,
                18577619936, 14130345958]
    Des_USER_NO = desensitization_hash(USER_NO)
    print(Des_USER_NO)

    Des_PHONE_NO = md5(PHONE_NO)
    print(Des_PHONE_NO)

    
    


