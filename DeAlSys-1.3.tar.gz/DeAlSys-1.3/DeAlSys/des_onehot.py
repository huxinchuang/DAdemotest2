from sklearn.preprocessing import OneHotEncoder
from tkinter import _flatten


# 1. 0_1展示的onehot表示函数
# 统计data_list中各项出现的频率，返回排序后列表
def get_default_order(data_list, sort_order):
    """
    根据data_list中各项出现的频率进行排序，返回排序后列表
    :param data_list: 待脱敏的列表
    :param sort_order: 可能的取值及排序方式： 'Str_sort'：直接进行字符串ascii码值排序； 'Freq_sort'：按照频率排序
    :return: 按照待处理列表中各项出现的频率进行排序，返回排序后的列表
    """
    # 首先判定输入合法
    assert sort_order in ['Str_sort', 'Freq_sort']

    default_order = []          # 存储排序后的列表
    data_set = set(data_list)   # 利用set去重，获取待处理列表中的项的种类
    data_dict = {}              # 声明一个列表，用于统计各项出现频率
    for index, item in enumerate(data_set):
        data_dict[item] = 0

    for i in range(len(data_list)):     # 统计出现频率
        data_dict[data_list[i]] += 1

    if sort_order == 'Str_sort':
        data_dict = sorted(data_dict.items(), key=lambda x: x[0])  # 按照keys()排序
    else:
        data_dict = sorted(data_dict.items(), key=lambda x: x[1], reverse=True)  # 按照values()排序

    for i in range(len(data_dict)):
        default_order.append(list(data_dict[i])[0])

    return default_order


# 对“二类数据”进行脱敏
def desensitization_onehot_01(unprocessed_data, sort_order='Specified_sort', default_order=None):
    """
    对‘二类one_hot’类型数据进行脱敏
    :param unprocessed_data: 待脱敏列表
    :param sort_order: 可能的取值及排序方式：
                        Specified_sort：指定的default_order； Str_sort：直接进行字符串ascii码值排序； Freq_sort：按照频率排序
    :param default_order: 二值列表，default_order[0]表示第一类，default_order[1]表示第二类
    :return:
    """
    # 判定输入合法
    assert sort_order in ['Specified_sort', 'Str_sort', 'Freq_sort']

    if sort_order != 'Specified_sort':
        default_order = get_default_order(unprocessed_data, sort_order)

    Des_data = [1] * len(unprocessed_data)  # 默认为default_order[0], 置为'1'

    for i in range(len(unprocessed_data)):
        if unprocessed_data[i] == default_order[1]:  # default_order[1]则置为0
            Des_data[i] = 0

    return Des_data


# 2. 用onehot编码表示的脱敏数据项

# 对‘多值one_hot’类型数据进行统一脱敏
def desensitization_onehot_mul_val(unprocessed_data, sort_order='Specified_sort', default_order=None):
    """
    对‘多值one_hot’类型数据进行脱敏
    :param unprocessed_data: 待脱敏数据
    :param sort_order: 可能的取值及排序方式：
                        Specified_sort：指定的default_order； Str_sort：直接进行字符串ascii码值排序； Freq_sort：按照频率排序
    :param default_order: 指定的排序列表（默认无）
    :return:
    """
    # 首先判定输入合法
    assert sort_order in ['Specified_sort', 'Str_sort', 'Freq_sort']

    if sort_order != 'Specified_sort':
        default_order = get_default_order(unprocessed_data, sort_order)

    des_list = []               # 存储脱敏后的列表

    # 设置onehot编码参数
    fit_list = []
    for i in range(len(default_order)):
        fit_list.append([i])
    enc = OneHotEncoder()
    enc.fit(fit_list)

    for i in range(len(unprocessed_data)):
        num_i = default_order.index(unprocessed_data[i])
        # 使用_flatten()将二维列表转为一维列表
        des_list.append(list(_flatten(enc.transform([[num_i]]).toarray().tolist())))
        # des_car_list.append(enc.transform([[num_i]]).toarray().tolist())

    return des_list


if __name__ == '__main__':
    # print('可供选择的职业：工人、公务员、个体商人、教师、程序员、学生')
    # PROFESSION_List = ['工人', '公务员', '个体商人', '教师', '程序员', '学生', '工人', '公务员', '教师', '程序员']
    # # Des_pro_list = onehot_mul_val(PROFESSION_List, ['工人', '公务员', '个体商人', '教师', '程序员', '学生'])
    # Des_pro_list = onehot_mul_val(PROFESSION_List, sort_order='Freq_sort')
    # print(Des_pro_list)

    print('可供选择的手机系统：Symbian、Palm、BlackBerry、ios、Windows mobile、Linux、Android、HarmonyOS')
    OS_List = ['Symbian', 'Palm', 'BlackBerry', 'ios', 'Windows mobile', 'Linux', 'Android', 'HarmonyOS']
    ans = desensitization_onehot_mul_val(OS_List, 'Str_sort')
    print(ans)

    # print('可供选择的用户等级：小富、大富、百富、巨富')
    # User_Value_List = ['小富', '大富', '百富', '巨富', '巨富', '百富', '小富', '大富']
    # ans = onehot_User_Value(User_Value_List)
    # print(ans)