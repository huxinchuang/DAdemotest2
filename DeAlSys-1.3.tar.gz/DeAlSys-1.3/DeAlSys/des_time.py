"""
文件说明：对时间相关的字段进行脱敏处理
原理：
"""
import datetime
from .des_normalization import desensitization_normalized


# 使用Max-min归一化法对“时间类”数据进行脱敏
def desensitization_time(time_data, time_granularity='day'):
    """
    使用Max-min归一化法对“时间类”数据进行脱敏，首先求得指定粒度的时间间隔，然后对该时间间隔进行Max-min归一化处理
    :param time_data: 输入的待脱敏的时间类数据列表：[Timestamp('2018-09-02 00:00:00'), Timestamp('2018-02-02 00:00:00')]
    :param time_granularity: 用户可选的时间粒度：'day': 截取间隔的天数；‘hour’:截取间隔的小时数; 'second': 截取间隔的秒数
    :return: 脱敏后的数据列表
    """
    # 判定：输入的粒度在合法范围内
    assert time_granularity in ['day', 'hour', 'second']

    time_interval = []
    start_time = datetime.datetime(2000, 1, 1, 0, 0, 0)    # 起始日期
    for i in range(len(time_data)):

        year = time_data[i].year
        month = time_data[i].month
        day = time_data[i].day
        hour = time_data[i].hour
        minute = time_data[i].minute
        second = time_data[i].second

        curr_time = datetime.datetime(year, month, day, hour, minute, second)
        time_interval_i = curr_time - start_time

        if time_granularity == 'day':
            time_interval.append(time_interval_i.days)
        elif time_granularity == 'hour':
            time_interval.append(time_interval_i.total_seconds() / 3600)
        elif time_granularity == 'second':
            time_interval.append(time_interval_i.total_seconds())

    des_time_interval = desensitization_normalized(time_interval)
    return des_time_interval


if __name__ == '__main__':
    time_data = ['2018-09-01/12:12:12', '2018-02-02/21:32:03', '2019-08-02/03:43:12']     # 待脱敏时间列表
    Cate_data = desensitization_time(time_data, time_granularity='second')
    print(Cate_data)