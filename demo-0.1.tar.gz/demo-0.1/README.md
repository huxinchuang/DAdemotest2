# python-sdk
安装和使用SDK：
1. 解压，进入主目录下
2. python setup.py install 安装
3. import Demo 在python程序中，调用安装好的Demo包

修改时间：2022/3/7-胡
