#!/usr/bin/env python
#-*- coding:utf-8 -*-

#from numpy import argmax
from calendar import c
from dataclasses import dataclass
import re
from functools import reduce
import numpy as np
def test1():
    print('test1 success!!!')

def test():
    print('test success!!!')

def demo(filename):
    print('----------1.Max-Min------------')
    #fd=open('E:\FederatedLearning\python-sdk-master\data.txt','r')
    fd = open(filename, 'r')
    fd1 = fd.readline()

    total_data=re.sub(r','," ",fd1)
    a=total_data.replace('[','')
    b=a.replace(']','')
    c=b.split()
    #print(len(c))

    length=len(c[2])

    p=input("please input the number:")
    q=int(p)

    n=[0 for _ in range(len(c))]
    data=[0 for _ in range(len(c))]

    for i in range(len(c)):
        n[i]= int(c[i])

    #for i in range(len(c)):
        data=(int((q-min(n))/(max(n)-min(n))*10000)/10000)
    #data=(int((n[3]-min(n))/(max(n)-min(n))*10000)/10000)
    #file = open("F:\data_1.txt",'w')
    #file.write(str(data))
    #fd.close
    print("after normalization is:",end=' ')
    print(data)
    #print("success max-min!")

    fd.close()
