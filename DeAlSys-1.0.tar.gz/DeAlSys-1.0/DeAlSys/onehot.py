from sklearn.preprocessing import OneHotEncoder
from itertools import chain
from tkinter import _flatten

# 1. 0_1展示的onehot表示函数

# 对“性别”进行脱敏
def onehot_Gender(gen):
    Des_gen = [1] * len(gen)        # 默认为男士，置为'1'
    for i in range(len(gen)):
        if gen[i] == '女':  # 女性则表示为0
            Des_gen[i] = 0

    return Des_gen


# 对“是否有房”进行脱敏
def onehot_House(hou):
    Des_hou = [1] * len(hou)  # 默认为'有房'，置为'1'
    for i in range(len(hou)):
        if hou[i] == '无':  # 无房则表示为‘0’
            Des_hou[i] = 0
    return Des_hou


# 2. 用onehot编码表示的脱敏数据项
# 对这些数据的脱敏，如“职业”数据。是系统直接设定默认的职业种类及其编码，
# 还是设置数据库、根据每次需脱敏的数据的职业分布情况动态设置编码并将其存入数据库？

# 对”职业“数据进行脱敏

def GetCarNum(career):
    """
    根据输入的职业，返回其对应的编号
    :param career:
    :return:
    """
    a = -1

    if career == '工人':
        a = 0
    elif career == '公务员':
        a = 1
    elif career == '个体商人':
        a = 2
    elif career == '教师':
        a = 3
    elif career == '程序员':
        a = 4
    elif career == '学生':
        a = 5
    else:
        a = 6

    return a


def onehot_career(career_list):
    """
    使用onehot编码对职业数据脱敏（当前是系统直接设定默认的职业种类及其编码）
    :param career_list: 输入的待脱敏的职业数据列表
    :return: 输入列表中每一个职业对应的onehot编码表示
    """
    des_car_list = []
    enc = OneHotEncoder()
    enc.fit([[0], [1], [2], [3], [4], [5]])
    for i in range(len(career_list)):
        num_i = GetCarNum(career_list[i])
        # 使用_flatten()将二维列表转为一维列表
        des_car_list.append(list(_flatten(enc.transform([[num_i]]).toarray().tolist())))
        # des_car_list.append(enc.transform([[num_i]]).toarray().tolist())

    return des_car_list


# 对“手机操作系统”进行脱敏

def GetOSNum(os):
    """
    根据输入的操作系统表示，返回其对应的编码
    :param os:
    :return:
    """
    a = -1
    if os == 'Symbian':
        a = 0
    elif os == 'Palm':
        a = 1
    elif os == 'BlackBerry':
        a = 2
    elif os == 'ios':
        a = 3
    elif os == 'Windows mobile':
        a = 4
    elif os == 'Linux':
        a = 5
    elif os == 'Android':
        a = 6
    elif os == 'HarmonyOS':
        a = 7

    return a


def onehot_OS(os_list):
    """
    使用onehot编码对手机操作系统数据脱敏
    :param os_list: 输入的待脱敏的手机操作系统数据列表
    :return:
    """
    des_os_list = []
    enc = OneHotEncoder()
    enc.fit([[0], [1], [2], [3], [4], [5], [6], [7]])

    for i in range(len(os_list)):
        num_i = GetOSNum(os_list[i])
        # 使用_flatten()将二维列表转为一维列表
        des_os_list.append(list(_flatten(enc.transform([[num_i]]).toarray().tolist())))
        # des_car_list.append(enc.transform([[num_i]]).toarray().tolist())

    return des_os_list


# 对'用户等级'数据进行脱敏处理

def GetUserValueNum(user_value):
    """
    根据用户等级，返回其对应的编码
    :param user_value:
    :return:
    """
    a = -1
    if user_value == '小富':
        a = 0
    elif user_value == '大富':
        a = 1
    elif user_value == '百富':
        a = 2
    elif user_value == '巨富':
        a = 3
    return a


def onehot_User_Value(user_value_list):
    """
    使用onehot编码对用户等级数据脱敏
    :param user_value_list: 待脱敏的用户等级列表数据
    :return: 脱敏后的对应列表
    """
    des_user_value = []
    enc = OneHotEncoder()
    enc.fit([[0], [1], [2], [3]])

    for i in range(len(user_value_list)):
        num_i = GetUserValueNum(user_value_list[i])
        # 使用_flatten()将二维列表转为一维列表
        des_user_value.append(list(_flatten(enc.transform([[num_i]]).toarray().tolist())))
        # des_car_list.append(enc.transform([[num_i]]).toarray().tolist())

    return des_user_value


if __name__ == '__main__':
    # print('可供选择的职业：工人、公务员、个体商人、教师、程序员、学生')
    # PROFESSION_List = ['工人', '公务员', '个体商人', '教师', '程序员', '学生', '工人', '公务员', '教师', '程序员']
    # Des_pro_list = onehot_career(PROFESSION_List)
    # print(Des_pro_list)

    print('可供选择的手机系统：Symbian、Palm、BlackBerry、ios、Windows mobile、Linux、Android、HarmonyOS')
    OS_List = ['Symbian', 'Palm', 'BlackBerry', 'ios', 'Windows mobile', 'Linux', 'Android', 'HarmonyOS']
    ans = onehot_OS(OS_List)
    print(ans)

    # print('可供选择的用户等级：小富、大富、百富、巨富')
    # User_Value_List = ['小富', '大富', '百富', '巨富', '巨富', '百富', '小富', '大富']
    # ans = onehot_User_Value(User_Value_List)
    # print(ans)