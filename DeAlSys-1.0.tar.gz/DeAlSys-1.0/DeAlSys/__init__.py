from .onehot import *
from .ConsecutiveData import *
from .main_test import *
from .Normalization import *
from .hash import *
from .time_interval import *


def test():
    print('helloworld!!!')