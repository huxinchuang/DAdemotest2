"""
文件说明：对时间相关的字段进行脱敏处理
原理：
"""
import datetime
from .Normalization import MaxMin_Mormal


# 使用Max-min归一化法对“最近交易时间”进行脱敏
def Lately_Trade_Time(time_list):
    """
    使用Max-min归一化法对“最近交易时间”进行脱敏
    :param time_list: 最近交易时间列表 ['2018-09-0', '2018-02-0', '2019-08-2']
    :return:
    """
    time_inter = []
    start_time = datetime.datetime(2000, 1, 1)    # 起始日期
    for i in range(len(time_list)):
        year = int(time_list[i][0:4])
        month = int(time_list[i][5:7])
        day = int(time_list[i][8:])
        curr_time = datetime.datetime(int(time_list[i][0:4]), int(time_list[i][5:7]), int(time_list[i][8:]))
        time_inter_i = curr_time - start_time
        time_inter.append(time_inter_i.days)
    des_time_inter = MaxMin_Mormal(time_inter)
    return des_time_inter


if __name__ == '__main__':
    time_list = ['2018-09-1', '2018-02-1', '2019-08-2']     # 待脱敏年龄列表
    Cate_Age = Lately_Trade_Time(time_list)
    print(Cate_Age)