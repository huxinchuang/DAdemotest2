from .ConsecutiveData import boxOperation_age
from .onehot import onehot_Gender, onehot_House, onehot_career, onehot_OS, onehot_User_Value
from .Normalization import MaxMin_Mormal
from .hash import md5
from .time_interval import Lately_Trade_Time
import pandas as pd
import numpy as np

def DeAlTest(input_src,output_src):
    #data = pd.read_excel('./data/test_data3.xlsx')
    data = pd.read_excel(input_src)


    # 对”用户编号“数据脱敏（hash脱敏）
    user_no = np.array(data.iloc[:, [0]].stack()).tolist()  # 读取第一列数据：用户编号，然后将pandas读取的数据转化为list
    Des_user_no = md5(user_no)
    # print(Des_user_no)

    # 对'性别'数据脱敏 （onehot）
    genders = np.array(data.iloc[:, [1]].stack()).tolist()   # 读取第二列数据：性别，然后将pandas读取的数据转化为list
    Des_genders = onehot_Gender(genders)
    # print(Des_genders)

    # 对'年龄'数据脱敏 (连续值脱敏-离散化-分箱脱敏)
    ages = np.array(data.iloc[:, [2]].stack()).tolist()   # 读取第三列数据：年龄，然后将pandas读取的数据转化为list
    Des_ages = boxOperation_age(ages)
    # print(Des_ages)

    # 对”职业“数据进行脱敏（one-hot脱敏）
    PROFESSIONs = np.array(data.iloc[:, [3]].stack()).tolist()  # 读取第四列数据：职业，然后将pandas读取的数据转化为list
    Des_pro = onehot_career(PROFESSIONs)
    # print(Des_pro)

    # 对'薪资'数据脱敏 （max-min归一化脱敏）
    salarys = np.array(data.iloc[:, [4]].stack()).tolist()   # 读取第五列数据：年薪，然后将pandas读取的数据转化为list
    Des_salarys = MaxMin_Mormal(salarys)
    # print(Des_salarys)

    # 对”手机号码“数据进行脱敏（one-hot脱敏）
    PHONE_NOs = np.array(data.iloc[:, [5]].stack()).tolist()  # 读取第六列数据：手机号码，然后将pandas读取的数据转化为list
    Des_pho = md5(PHONE_NOs)
    # print(Des_pho)

    # 对'是否有房'数据脱敏（onehot）
    House = np.array(data.iloc[:, [6]].stack()).tolist()   # 读取第七列数据：房，然后将pandas读取的数据转化为list
    Des_hou = onehot_House(House)
    # print(Des_hou)

    # 对'操作系统'数据进行脱敏处理（one-hot脱敏）
    PHONE_OS = np.array(data.iloc[:, [7]].stack()).tolist()  # 读取第八列数据：职业，然后将pandas读取的数据转化为list
    Des_phone = onehot_OS(PHONE_OS)
    # print(Des_phone)

    # # 对'用户等级'数据进行脱敏处理(one-hot脱敏)
    WO_USER_VALUE = np.array(data.iloc[:, [8]].stack()).tolist()  # 读取第九列数据：用户等级，然后将pandas读取的数据转化为list
    Des_WO_USER = onehot_User_Value(WO_USER_VALUE)
    # print(Des_WO_USER)

    # 对'最近一个月登录次数'数据进行脱敏处理（max-min归一化脱敏）
    LOGIN_NUM1 = np.array(data.iloc[:, [9]].stack()).tolist()  # 读取第十列数据：最近一个月登录次数，然后将pandas读取的数据转化为list
    Des_login_num = MaxMin_Mormal(LOGIN_NUM1)
    # print(Des_login_num)

    # 对'最近六个月交易次数'数据进行脱敏处理（max-min归一化脱敏）
    TRADE_ALL_NUM6 = np.array(data.iloc[:, [10]].stack()).tolist()  # 读取第十一列数据：最近6个月的交易次数，然后将pandas读取的数据转化为list
    Des_Trade_num6 = MaxMin_Mormal(TRADE_ALL_NUM6)
    # print(Des_Trade_num6)

    # 对'最近6个月的交易金额'数据进行脱敏处理（max-min归一化脱敏）
    TRADE_ALL_AMT6 = np.array(data.iloc[:, [11]].stack()).tolist()  # 读取第十二列数据：最近6个月的交易金额，然后将pandas读取的数据转化为list
    Des_Trade_AMT6 = MaxMin_Mormal(TRADE_ALL_AMT6)
    # print(Des_Trade_AMT6)

    # 对'最近交易时间'数据进行脱敏处理（先求时间间隔，再对时间间隔做Max-Min归一化脱敏）
    LATELY_ALL_TRADE_TIME = np.array(data.iloc[:, [12]].stack())    # 读取第十三列数据：最近交易时间，然后将pandas读取的数据转化为list
    LATELY_ALL_TRADE_TIME = [str(LATELY_ALL_TRADE_TIME[i])[:10] for i in range(len(LATELY_ALL_TRADE_TIME))]

    Des_Lately_Trade_Time = Lately_Trade_Time(LATELY_ALL_TRADE_TIME)
    print(Des_Lately_Trade_Time)

    # 保存脱敏后的数据
    frame = pd.DataFrame({'用户编号': Des_user_no,
                          '性别': Des_genders,
                          '年龄': Des_ages,
                          '职业': Des_pro,
                          '薪资': Des_salarys,
                          '手机号码': Des_pho,
                          '有房': Des_hou,
                          '操作系统': Des_phone,
                          '用户等级': Des_WO_USER,
                          '最近一个月登录次数': Des_login_num,
                          '最近六个月交易次数': Des_Trade_num6,
                          '最近六个月的交易金额': Des_Trade_AMT6,
                          '最近交易时间': Des_Lately_Trade_Time
                          })
    frame.to_csv(output_src + '/Des_data2.csv', index=False, sep=',')
    print('Main test is over')
    print('please check output!')
