import numpy as np


def MaxMin_Mormal(data_list):
    """
    对输入数据进行最大—最小标准化
    :param data_list: 输入数据列表
    :return: 标准化后的数据列表
    """
    return (data_list - np.min(data_list, axis=0)) / (np.max(data_list, axis=0) - np.min(data_list, axis=0))


if __name__ == '__main__':
    salarys = [978619, 32654, 512924, 157720, 764750, 699803, 757468, 525079, 28842, 176911]
    Normal_Sal = MaxMin_Mormal(salarys)
    print(Normal_Sal)


