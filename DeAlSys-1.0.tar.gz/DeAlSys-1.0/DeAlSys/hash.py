"""
文件说明：哈希脱敏算法实现
"""
import hashlib

"""
def hash256(data):
    binaries = data.encode('utf8')
    res = hashlib.sha256(binaries).hexdigest()
    return res


def hash224(data):
    binaries = data.encode('utf8')
    res = hashlib.sha224(binaries).hexdigest()
    return res
"""


def md5(data_list):
    res = []
    for i in range(len(data_list)):
        binaries = str(data_list[i]).encode('utf8')
        res.append(hashlib.md5(binaries).hexdigest())
    return res


if __name__ == '__main__':
    USER_NO = [719112608, 634908102, 935065281, 862633939, 910625206, 208955311, 427389667, 571340345, 308527721, 589805272]
    PHONE_NO = [14392372461, 15358753163, 15368219577, 18679118120, 18514343397, 15373199026, 14923115681, 14506583419,
                18577619936, 14130345958]
    Des_USER_NO = md5(USER_NO)
    print(Des_USER_NO)

    Des_PHONE_NO = md5(PHONE_NO)
    print(Des_PHONE_NO)

    
    


